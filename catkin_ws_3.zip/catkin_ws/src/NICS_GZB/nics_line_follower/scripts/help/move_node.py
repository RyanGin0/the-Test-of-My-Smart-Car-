#!/usr/bin/python
#-*- encoding: utf8 -*-
import sys
import rospy
from geometry_msgs.msg import Twist
import time
import os

def pub_action(pub,vel,t):
    for i in range(int(abs(t)/0.025)):
        pub.publish(vel)
        time.sleep(0.025)
    for i in range(8):
        pub.publish(Twist())
        time.sleep(0.025)



def movenode(linear,angel):
        rospy.init_node('move_node', anonymous=True)
        rospy.logwarn('motion node set up.')
        # 发布控制速度
        pub=rospy.Publisher('/AKM_1/cmd_vel', Twist, queue_size=1)
	rate=rospy.Rate(5)	
	vel=Twist()
        while  not rospy.is_shutdown():

            vel.linear.x=linear
	    vel.angular.z=angel
            pub_action(pub,vel,1)
	    rate.sleep()


if __name__== '__main__':
    try:
	movenode(float(sys.argv[1]),float(sys.argv[2]))
    except rospy.ROSInterruptException:
	pass
