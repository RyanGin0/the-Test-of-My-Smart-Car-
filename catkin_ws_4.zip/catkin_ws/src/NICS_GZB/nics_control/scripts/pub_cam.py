#!/usr/bin/python
#-*- encoding: utf8 -*-
import rospy
import cv2
import numpy as np
import math
from std_msgs.msg import Int32
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError


class Pubcam:

    def __init__(self):
        rospy.init_node('pub_cam', anonymous=True)
        self.image_ = None
        self.bridge_ = CvBridge()
        self.rate=rospy.Rate(20)

        # 接收摄像头图像
        self.imageSub_ = rospy.Subscriber('/AKM_1/camera/rgb/image_raw', Image, self.imageCallback)  
	rospy.spin()
	cv2.imshow("frame",self.imageSub_)
	cv2.waitkey(3)
     

        #发布
        t_span=rospy.get_time()-t_start
        msg = Int32()
        msg.data = int(center)
        self.posPub_.publish(msg)


if __name__ == '__main__':
    cn = Pubcam()
